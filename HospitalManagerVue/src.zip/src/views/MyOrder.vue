<template>
    <div>


        <el-row :gutter="20">
            <!-- 循环渲染 el-col 组件 -->
            <el-col :span="6" v-for="(item, index) in orderData" :key="index">

                <el-card style="width: 300px; ">
                    <!-- 卡片信息部分 -->
                    <template #header>
                        <div style="text-align: center;">
                            <p class="doctor-name">挂号单号&nbsp;{{ item.oId }} </p>
                        </div>
                    </template>
                    <!-- 卡片图片部分 -->
                    <div style="text-align: left;">
                        <div style="text-align: left;">
                            <p class="doctor-name">医生姓名&nbsp;{{ item.dName }} </p>
                        </div>
                        <div style="text-align: left;">
                            <p class="doctor-name">科室&nbsp;{{ item.dSection }} </p>
                        </div>
                        <div style="text-align: left;">
                            <p class="doctor-name">挂号时间&nbsp;{{ item.oStart }} </p>
                        </div>
                        <div style="text-align: left;">
                            <p class="doctor-name">挂号状态&nbsp; <el-tag type="success" v-if="
                                item.oState === 1 &&
                                item.oPriceState === 1
                            ">已完成</el-tag>
                                <el-tag type="danger" v-if="
                                    item.oState === 0 && item.oState === 0
                                ">未完成</el-tag>
                            </p>
                        </div>
                        <div style="text-align: left;">
                            <p class="doctor-name">缴费状态&nbsp; <el-tag type="success"
                                    v-if="item.oPriceState === 1">已缴费</el-tag>
                                <!-- <el-tag type="danger" v-if="scope.row.oPriceState === 0 && scope.row.oState === 1">未缴费</el-tag> -->
                                <el-button type="warning" icon="iconfont icon-r-mark1" style="font-size: 14px" v-if="
                                    item.oPriceState === 0
                                " @click="priceClick(item.oId, item.dId)">
                                    点击缴费</el-button>
                            </p>
                        </div>
                        <div style="text-align: left;">
                            <p class="doctor-name">报告单&nbsp;
                                <el-button type="success" icon="iconfont icon-r-find" style="font-size: 14px"
                            @click="seeReport(item.oId)" v-if="
                            item.oState === 1 &&
                            item.oPriceState === 1
                            "> 查看</el-button>
                            </p>
                        </div>
                    </div>
                </el-card>

            </el-col>
        </el-row>

       
        <!-- 评价对话框 -->
        <el-dialog title="用户评价" :visible.sync="starVisible">
            <div>
                <h3>
                    请对工号：{{ dId }}&nbsp;医生：{{ dName }}&nbsp;进行评价
                </h3>
            </div>
            <div>
                <el-rate v-model="star" show-text> </el-rate>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button @click="starVisible = false" style="font-size: 18px;"><i class="iconfont icon-r-left"
                        style="font-size: 20px;"></i> 取 消</el-button>
                <el-button type="primary" @click="starClick" style="font-size: 18px;"><i class="iconfont icon-r-yes"
                        style="font-size: 20px;"></i> 确 定</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script>
import request from "@/utils/request.js";
import jwtDecode from "jwt-decode";
import { getToken } from "@/utils/storage.js";
export default {
    name: "MyOrder",
    data() {
        return {
            userId: 1,
            orderData: [],
            star: 5,
            starVisible: false,
            dId: 1,
            dName: "",
        };
    },
    methods: {
        //评价点击确认
        starClick() {
            console.log(this.star);
            console.log(this.dId);
            request
                .get("doctor/updateStar", {
                    params: {
                        dId: this.dId,
                        dStar: this.star,
                    },
                })
                .then((res) => {
                    if (res.data.status !== 200)
                        return this.$message.error("评价失败");
                    this.$message.success("谢谢您的评价");
                    this.starVisible = false;
                });
        },
        //查看报告单
        seeReport(id) {
            window.location.href =
                "http://localhost:9000/patient/pdf?oId=" + id;
        },
        //点击缴费按钮
        priceClick(oId, dId) {
            request
                .get("order/updatePrice", {
                    params: {
                        oId: oId,
                    },
                })
                .then((res) => {
                    if (res.data.status !== 200) {
                        this.$message.error("请求数据失败");
                        return;
                    }
                    this.$message.success("单号 " + oId + " 缴费成功！");
                    request
                        .get("admin/findDoctor", {
                            params: {
                                dId: dId,
                            },
                        })
                        .then((res) => {
                            if (res.data.status !== 200)
                                return this.$message.error("请求数据失败");
                            this.dId = res.data.data.dId;
                            this.dName = res.data.data.dName;
                        });
                    this.starVisible = true;
                    this.requestOrder();
                });
        },
        //请求挂号信息
        requestOrder() {
            request
                .get("patient/findOrderByPid", {
                    params: {
                        pId: this.userId,
                    },
                })
                .then((res) => {
                    if (res.data.status !== 200)
                        this.$message.error("请求数据失败");
                    this.orderData = res.data.data;
                    this.orderData.dSection = res.data.data.map(item => item.doctor.dSection);
                    //console.log(res.data.data.map(item => item.doctor.dSection));
                    console.log(this.orderData.oId);
                    console.log(this.orderData.pName);
                    console.log(res);
                });
        },
        //token解码
        tokenDecode(token) {
            if (token !== null) return jwtDecode(token);
        },
    },
    created() {
        // 解码token
        //this.orderData.pName = this.tokenDecode(getToken()).pName;
        //this.orderData.pCard = this.tokenDecode(getToken()).pCard;
        this.userId = this.tokenDecode(getToken()).pId;
        console.log(this.orderData.pName);
        //this.orderData.pName = "dasda"
        this.requestOrder();
    },
};
</script>
<style lang="scss" scoped>
.el-dialog div {
    text-align: center;
    margin-bottom: 8px;
}
</style>