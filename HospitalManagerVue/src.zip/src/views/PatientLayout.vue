<template>
 <div class="container">
    <!-- 左边滚动图片区域 -->
    <div class="left">
      <el-carousel :interval="3000" arrow="always" indicator-position="outside">
        <el-carousel-item v-for="(image, index) in images" :key="index">
          <img :src="image" alt="carousel image" style="width: 100%; height: 100%; object-fit: cover;">
        </el-carousel-item>
      </el-carousel>
    </div>
    <!-- 右边科室位置信息区域 -->
   <!-- 右边科室位置信息区域 -->
   <!-- 右边科室位置信息区域 -->
   <div class="right">
      <h2 class="title">医院科室楼层及门牌号信息</h2>
      <el-scrollbar ref="scrollbarRef" style="height: 300px;">
        <el-table :data="departmentList" style="width: 100%">
          <el-table-column prop="departmentName" label="科室名称" ></el-table-column>
          <el-table-column prop="floor" label="楼层" ></el-table-column>
          <el-table-column prop="roomNumber" label="门牌号" ></el-table-column>
        </el-table>
      </el-scrollbar>
    </div>
  </div>
</template>
<script>
import request from "@/utils/request.js";
import { toLoad } from "@/utils/initialize.js";
export default {
  name: "PatientLayout",
  data() {
    return {
      images: [
        require('@/assets/宣传1.webp'),
        require('@/assets/宣传2.webp'),
        require('@/assets/宣传3.webp')
      ], departmentList: [
        { departmentName: '内科', floor: '2 楼', roomNumber: '201' },
        { departmentName: '外科', floor: '2 楼', roomNumber: '202' },
        { departmentName: '妇产科', floor: '3 楼', roomNumber: '301' },
        { departmentName: '儿科', floor: '3 楼', roomNumber: '302' },
        { departmentName: '眼科', floor: '4 楼', roomNumber: '401' },
        { departmentName: '口腔科', floor: '4 楼', roomNumber: '402' },
        { departmentName: '皮肤科', floor: '5 楼', roomNumber: '501' },
        { departmentName: '中医科', floor: '5 楼', roomNumber: '502' }
      ]
    };
  },
  mounted() {
    // 组件挂载后启动自动滚动
    this.startAutoScroll();
  },
  methods: {
    startAutoScroll() {
      // 获取 el-scrollbar 组件的 DOM 元素
      const scrollbar = this.$refs.scrollbarRef.$el.querySelector('.el-scrollbar__wrap');
      // 设置滚动间隔（毫秒）
      const interval = 20;
      // 设置每次滚动的距离
      const step = 1;
      // 开启定时器实现自动滚动
      this.scrollInterval = setInterval(() => {
        // 滚动到底部后重置滚动位置
        if (scrollbar.scrollTop + scrollbar.clientHeight >= scrollbar.scrollHeight) {
          scrollbar.scrollTop = 0;
        } else {
          // 正常滚动
          scrollbar.scrollTop += step;
        }
      }, interval);
    }
  },
  beforeDestroy() {
    // 组件销毁前清除定时器，避免内存泄漏
    if (this.scrollInterval) {
      clearInterval(this.scrollInterval);
    }
  }
};

</script>
<style lang="scss" scoped>
 .container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
}

.left {
  width: 50%;
  height: 300px;
}

.right {
  margin-left: 10px;
  width: 50%;
}

h2 {
  margin-bottom: 10px;
}
.title {
  text-align: center; /* 标题文字居中 */
  margin-bottom: 10px;
  font-weight: bold; /* 标题文字加粗 */
  color:blue
}

.el-table .cell {
  font-size: 16px;
  font-weight: bold; /* 标题文字加粗 */
}

.el-table td {
  text-align: center; /* 表格内容文字居中 */
  font-weight: bold; /* 表格内容文字加粗 */
  color: #333; /* 表格内容文字颜色 */
}
.userFont {
  height: 150px;
  width: 250px;
  float: right;
  color: white;

  .spanCure {
    font-size: 15px;
    margin-top: 60px;
    margin-bottom: 15px;
  }

  .spanPeople {
    font-size: 18px;
  }
}

.userImage {
  height: 150px;
  width: 150px;
  font-size: 130px;
  color: white;
  position: relative;
  left: 40px;
  top: 10px;
  float: left;
}

.indexPeople {
  height: 200px;
  width: 440px;
  background: #66b1ff;
  float: left;
  margin: 30px;
  border-radius: 10px;
}
</style>